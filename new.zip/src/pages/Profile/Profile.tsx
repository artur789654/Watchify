function Profile() {
  return (
    <>Profile Page</>
  )
}

export default Profile;