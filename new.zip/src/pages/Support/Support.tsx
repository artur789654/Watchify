function Support(){
  return(
    <>Support page</>
  )
}

export default Support