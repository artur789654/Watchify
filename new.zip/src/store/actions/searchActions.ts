import { ThunkAction } from "redux-thunk";
import { RootState } from "..";
import {
  FETCH_SEARCH_FAILURE,
  FETCH_SEARCH_REQUEST,
  FETCH_SEARCH_SUCCESS,
  SearchActionsType,
} from "./actionTypes";
import { Dispatch } from "redux";
import axios from "axios";
import {
  SEARCH_MULTI_ENDPOINT,
  TMDB_API_KEY,
  TMDB_BASE_URL,
} from "../../helpers/apiConstants";
import { Movie, TVShow } from "../../types/media";

interface SearchResponse {
  results: (Movie | TVShow)[];
}

export const fetchSearch =
  (
    page: number = 1,
    query: string
  ): ThunkAction<void, RootState, unknown, SearchActionsType> =>
  async (dispatch: Dispatch) => {
    dispatch({ type: FETCH_SEARCH_REQUEST });
    try {
      const response = await axios.get<SearchResponse>(
        `${TMDB_BASE_URL}${SEARCH_MULTI_ENDPOINT}`,
        {
          params: {
            api_key: TMDB_API_KEY,
            page,
            query,
          },
        }
      );
      const searchResults = response.data;
      dispatch({
        type: FETCH_SEARCH_SUCCESS,
        payload: searchResults,
      });
    } catch (error: any) {
      dispatch({
        type: FETCH_SEARCH_FAILURE,
        payload: error.message,
      });
    }
  };
